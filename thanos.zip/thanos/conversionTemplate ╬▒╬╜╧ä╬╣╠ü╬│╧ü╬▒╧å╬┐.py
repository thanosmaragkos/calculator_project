# conversionTemplate.py

import customtkinter

class ConversionFrameTemplate(customtkinter.CTkFrame):
    def __init__(self, master, theme, sound_enabled=True):
        super().__init__(master, fg_color=theme["background"])
        self.theme = theme
        self.sound_enabled = sound_enabled

        # Ετικέτα τίτλου
        self.title_label = customtkinter.CTkLabel(
            self,
            text="Conversion Tool",
            font=("Arial", 18, "bold"),
            text_color=theme["display_text"]
        )
        self.title_label.pack(pady=20)

        # Είσοδος δεδομένων
        self.input_entry = customtkinter.CTkEntry(
            self,
            placeholder_text="Εισαγωγή τιμής",
            fg_color=theme["display_bg"],
            text_color=theme["display_text"]
        )
        self.input_entry.pack(pady=10, padx=20)

        # Είσοδος επιλογής μονάδων (dropdown)
        self.unit_from = customtkinter.CTkOptionMenu(
            self,
            values=["Option A", "Option B"],
            fg_color=theme["top_button_bg"],
            button_color=theme["top_button_bg"],
            text_color=theme["top_button_text"]
        )
        self.unit_from.pack(pady=5)

        self.unit_to = customtkinter.CTkOptionMenu(
            self,
            values=["Option A", "Option B"],
            fg_color=theme["top_button_bg"],
            button_color=theme["top_button_bg"],
            text_color=theme["top_button_text"]
        )
        self.unit_to.pack(pady=5)

        # Κουμπί υπολογισμού
        self.convert_button = customtkinter.CTkButton(
            self,
            text="Μετατροπή",
            command=self.convert_value,
            fg_color=theme["ac_button_bg"],
            text_color=theme["ac_button_text"],
            hover_color=theme["ac_hover"]
        )
        self.convert_button.pack(pady=15)

        # Αποτέλεσμα
        self.result_label = customtkinter.CTkLabel(
            self,
            text="Αποτέλεσμα:",
            font=("Arial", 14),
            text_color=theme["display_text"]
        )
        self.result_label.pack(pady=10)

    def convert_value(self):
        # Προσωρινή συμπεριφορά για δοκιμή
        try:
            value = float(self.input_entry.get())
            result = value * 2  # Dummy conversion
            self.result_label.configure(text=f"Αποτέλεσμα: {result}")
        except ValueError:
            self.result_label.configure(text="Μη έγκυρη είσοδος.")
