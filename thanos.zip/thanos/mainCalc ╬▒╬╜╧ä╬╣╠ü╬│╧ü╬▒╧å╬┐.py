#mainCalc.py
# Αυτό είναι το βασικό αρχείο της αριθμομηχανής
# Χρησιμοποιεί το CustomTkinter για το γραφικό περιβάλλον και υποστηρίζει διάφορα modes και themes

import customtkinter
from PIL import Image
from standardCalc import StandardCalculator
from themeManager import get_theme
from customtkinter import CTkLabel
from frameManager import frame_data  # Φορτώνει όλα τα διαθέσιμα frames/modes για την αριθμομηχανή
import os

# Ορίζουμε το dark mode ως αρχικό
customtkinter.set_appearance_mode("dark")

# Μεταβλητή για ενεργοποίηση/απενεργοποίηση ήχου
sound_enabled_global = True


# Συνάρτηση που επιστρέφει την κατάσταση του ήχου
def get_sound_state():
    return sound_enabled_global


# Η κύρια κλάση της εφαρμογής αριθμομηχανής
class MainCalculatorApp(customtkinter.CTk):
    def __init__(self):
        super().__init__()

        # Βασικές ρυθμίσεις παραθύρου
        self.geometry("400x600")
        self.bind_all("<Key>", self.on_key_press)
        self.bind("<Button-1>", self.on_click_outside_menu)  # Προσθήκη binding για click εκτός μενού


        # Καταστάσεις της εφαρμογής
        global sound_enabled_global
        self.sound_enabled = sound_enabled_global
        self.theme_mode = "dark"
        self.current_mode = "standard"
        self.sidebar_open = False
        self.sidebar_x = -200
        self.display_value = ""
        self.theme_buttons = {}
        self.mode_buttons = {}
        self.mode_icons = {}

        # Φόρτωση εικόνων για το UI
        sound_on_path = "images/sound_on.png"
        if os.path.exists(sound_on_path):
            self.sound_on_img = customtkinter.CTkImage(light_image=Image.open(sound_on_path), size=(24, 24))
        else:
            print(f"Warning: Image file '{sound_on_path}' not found.")
            self.sound_on_img = None  # Or use a default placeholder

        sound_off_path = "images/sound_off.png"
        if os.path.exists(sound_off_path):
            self.sound_off_img = customtkinter.CTkImage(light_image=Image.open(sound_off_path), size=(24, 24))
        else:
            print(f"Warning: Image file '{sound_off_path}' not found.")
            self.sound_off_img = None  # Or use a default placeholder
        menu_icon_path = "images/menu_icon.png"
        if os.path.exists(menu_icon_path):
            self.menu_icon_img = customtkinter.CTkImage(light_image=Image.open(menu_icon_path), size=(24, 24))
        else:
            print(f"Warning: Image file '{menu_icon_path}' not found.")
            self.menu_icon_img = None  # Or use a default placeholder

        close_icon_path = "images/close_icon.png"
        if os.path.exists(close_icon_path):
            self.close_icon = customtkinter.CTkImage(light_image=Image.open(close_icon_path), size=(24, 24))
        else:
            print(f"Warning: Image file '{close_icon_path}' not found.")
            self.close_icon = None  # Or use a default placeholder

        bullet_icon_path = "images/bullet.png"
        if os.path.exists(bullet_icon_path):
            self.bullet_icon = customtkinter.CTkImage(light_image=Image.open(bullet_icon_path), size=(14, 14))
        else:
            print(f"Warning: Image file '{bullet_icon_path}' not found.")
            self.bullet_icon = None  # Or use a default placeholder

        # Δημιουργία της πάνω μπάρας μενού
        self.top_bar_frame = customtkinter.CTkFrame(self, height=40, corner_radius=0)
        self.top_bar_frame.pack(fill="x")

        # Κουμπί εμφάνισης/απόκρυψης πλαϊνού μενού
        self.menu_button = customtkinter.CTkButton(
            self.top_bar_frame,
            text="",
            width=40,
            height=40,
            image=self.menu_icon_img,
            command=self.toggle_menu,
            fg_color=get_theme(self.theme_mode)["top_frame_bg"],    # το bg χρώμα του κουμπιού που ανοίγει/κλείνει το μενού
            corner_radius=6)
        self.menu_button.pack(side="left", padx=5)

        # Εμφάνιση του τρέχοντος mode
        self.mode_label_display = customtkinter.CTkLabel(
            self.top_bar_frame,
            text="Standard Calculator",
            font=("Arial", 16),
            text_color=get_theme(self.theme_mode)["menu_text_color"]
        )
        self.mode_label_display.pack(side="left", padx=10)

        # Κουμπί ήχου
        self.sound_button = customtkinter.CTkButton(
            self.top_bar_frame,
            image=self.sound_on_img,
            text="",
            width=40,
            height=40,
            command=self.toggle_sound,
            fg_color=get_theme(self.theme_mode)["top_frame_bg"] # το bg χρώμα του κουμπιού που ανοίγει/κλείνει τον ήχο
        )
        self.sound_button.pack(side="right", padx=5)

        # Πλαϊνό μενού (sidebar)
        self.sidebar_frame = customtkinter.CTkFrame(
            self, width=200, height=560,
            corner_radius=0,
            fg_color=get_theme(self.theme_mode)["top_frame_bg"] # το χρώμα του πλαϊνού μενού (ιδανικά ίδιο με το top_frame)
        )
        self.sidebar_frame.pack_propagate(False)
        self.sidebar_frame.place(x=-200, y=40)

        # Εσωτερικό του πλαϊνού μενού
        self.menu_inner_frame = customtkinter.CTkFrame(self.sidebar_frame, corner_radius=0)
        self.menu_inner_frame.pack(fill="both", expand=True, padx=10, pady=10)

        # Τίτλος ενότητας Mode
        section_label = customtkinter.CTkLabel(self.menu_inner_frame, text="Mode", font=("Arial", 14, "bold"))
        section_label.pack(anchor="w", pady=(5, 2))

        # Κουμπιά για εναλλαγή μεταξύ διαφορετικών λειτουργιών (frames)
        for mode, data in frame_data.items():
            icon_path = data.get("icon_path", "")
            if os.path.exists(icon_path):
                icon = customtkinter.CTkImage(light_image=Image.open(icon_path), size=(20, 20))
            else:
                print(f"Warning: Icon file '{icon_path}' not found for mode '{mode}'.")
                icon = None  # Or use a default placeholder
            self.mode_icons[mode] = icon

            btn = customtkinter.CTkButton(
                self.menu_inner_frame,
                text=mode.title(),
                corner_radius=6,
                image=icon,
                anchor="w",
                compound="left",
                command=lambda m=mode: self.set_mode_button(m),
                fg_color=get_theme(self.theme_mode)["top_button_bg"],
                text_color=get_theme(self.theme_mode)["menu_text_color"]
            )
            btn.pack(pady=2, padx=2, anchor="w", fill="x")
            self.mode_buttons[mode] = btn

        # Τίτλος ενότητας Theme (θέματα εμφάνισης)
        theme_label = customtkinter.CTkLabel(self.menu_inner_frame, text="Theme", font=("Arial", 14, "bold"))
        theme_label.pack(anchor="w", pady=(10, 2))

        # Κουμπιά επιλογής θέματος εμφάνισης
        for theme in ["dark", "light", "purple", "oceanic", "goth", "mondrian", "rainbow", "windows95", "excel2003"]:
            btn = customtkinter.CTkButton(
                self.menu_inner_frame,
                text=theme.capitalize(),
                corner_radius=6,
                image=self.bullet_icon,
                compound="left",
                anchor="w",
                width=180,
                height=28,
                font=("Arial", 12),

                command=lambda t=theme: self.set_theme_button(t)
            )
            btn.pack(pady=2, padx=2, anchor="w")
            self.theme_buttons[theme] = btn

        # Εκκίνηση του default frame (standard calculator)
        self.calculator_frame = None
        self.after(100, self.show_calculator_frame)
        self.after(150, lambda: self.set_theme_button(self.theme_mode))
        self.after(200, lambda: self.set_mode_button(self.current_mode))


####################################################################################################

    # Ορισμός του επιλεγμένου θέματος
    def set_theme_button(self, theme):
        self.switch_theme(theme)
        for k, b in self.theme_buttons.items():
            b.configure(fg_color=get_theme(self.theme_mode)["inner_frame_bg"],          #το χρώμα bg των κουμπιών του μενού για την επιλογή θέματος, ιδανικά ίδιο με το inner_frame
                        hover_color=get_theme(self.theme_mode)["special_button_fg"],    # το hover χρώμα των κουμπιών του μενού για την επιλογή θέματος
                        text_color=get_theme(self.theme_mode)["menu_text_color"]        # το χρώμα του κειμένου των κουμπιών του μενού για την επιλογή θέματος
            )
        if theme in self.theme_buttons:
            self.theme_buttons[theme].configure(fg_color=get_theme(self.theme_mode)["special_button_fg"])   # το χρώμα της active επιλογής

        self.sidebar_frame.configure(fg_color=get_theme(self.theme_mode)["slide_menu_bg"])          # το χρώμα του sidebar
        self.menu_inner_frame.configure(fg_color=get_theme(self.theme_mode)["inner_frame_bg"])      # το χρώμα του inner sidebar
        self.top_bar_frame.configure(fg_color=get_theme(self.theme_mode)["background"])             # το χρώμα της μπάρας του μενού
        self.menu_button.configure(
            fg_color=get_theme(self.theme_mode)["top_frame_bg"],            # το bg χρώμα του κουμπιού που ανοίγει/κλείνει το μενού (ιδανικά ίδιο με το top_frame)
            hover_color=get_theme(self.theme_mode)["top_button_hover"]      # το hover χρώμα του κουμπιού που ανοίγει/κλείνει το μενού
        )
        self.sound_button.configure(
            fg_color=get_theme(self.theme_mode)["top_frame_bg"],            # το bg χρώμα του κουμπιού που ανοίγει/κλείνει τον ήχο (ιδανικά ίδιο με το top_frame)
            hover_color=get_theme(self.theme_mode)["top_button_hover"],     # το hover χρώμα του κουμπιού που ανοίγει/κλείνει τον ήχο

        )

    # Ορισμός του επιλεγμένου mode (frame)
    def set_mode_button(self, mode):
        for k, b in self.mode_buttons.items():
            b.configure(fg_color=get_theme(self.theme_mode)["inner_frame_bg"],          # το χρώμα bg των κουμπιών του μενού για την επιλογή mode, ιδανικά ίδιο με το inner_frame
                        hover_color=get_theme(self.theme_mode)["special_button_fg"],    # το hover χρώμα των κουμπιών του μενού για την επιλογή mode
                        text_color = get_theme(self.theme_mode)["menu_text_color"]      # το χρώμα του κειμένου των κουμπιών του μενού για την επιλογή mode
                        )
        if mode in self.mode_buttons:
            self.mode_buttons[mode].configure(fg_color=get_theme(self.theme_mode)["special_button_fg"])
        self.switch_mode(mode)

    # Εναλλαγή εμφάνισης του πλαϊνού μενού
    def toggle_menu(self):
        if self.sidebar_open:
            self.menu_button.configure(image=self.menu_icon_img)
            self.slide_out()
        else:
            self.menu_button.configure(image=self.close_icon)
            self.slide_in()

    # Άνοιγμα πλαϊνού μενού με animation
    def slide_in(self):
        self.sidebar_x = -200

        def animate():
            if self.sidebar_x < 0:
                self.sidebar_x += 20
                self.sidebar_frame.place(x=self.sidebar_x, y=40)
                self.after(10, animate)
            else:
                self.sidebar_frame.place(x=0, y=40)
                self.sidebar_open = True

        if not self.sidebar_open:
            animate()

    # Κλείσιμο πλαϊνού μενού με animation
    def slide_out(self):
        def animate():
            if self.sidebar_x > -200:
                self.sidebar_x -= 20
                self.sidebar_frame.place(x=self.sidebar_x, y=40)
                self.after(10, animate)
            else:
                self.sidebar_frame.place(x=-200, y=40)
                self.sidebar_open = False

        if self.sidebar_open:
            animate()

    def on_click_outside_menu(self, event):
        if self.sidebar_open:
            # Συντεταγμένες sidebar
            sidebar_x1 = self.sidebar_frame.winfo_rootx()
            sidebar_y1 = self.sidebar_frame.winfo_rooty()
            sidebar_x2 = sidebar_x1 + self.sidebar_frame.winfo_width()
            sidebar_y2 = sidebar_y1 + self.sidebar_frame.winfo_height()
            # Συντεταγμένες κλικ
            click_x = self.winfo_pointerx()
            click_y = self.winfo_pointery()
            # Αν το κλικ είναι ΕΚΤΟΣ sidebar
            if not (sidebar_x1 <= click_x <= sidebar_x2 and sidebar_y1 <= click_y <= sidebar_y2):
                self.menu_button.configure(image=self.menu_icon_img)
                self.slide_out()


    # Προβολή του τρέχοντος επιλεγμένου calculator frame
    def show_calculator_frame(self):
        if self.calculator_frame:
            try:
                self.display_value = self.calculator_frame.get_display_value()
            except:
                self.display_value = ""
            self.calculator_frame.destroy()

        theme = get_theme(self.theme_mode)
        FrameClass = frame_data.get(self.current_mode, {}).get("frame", StandardCalculator)

        try:
            self.calculator_frame = FrameClass(self, theme=theme, sound_enabled=self.sound_enabled)
        except TypeError:
            self.calculator_frame = FrameClass(self)

        self.calculator_frame.pack(fill="both", expand=True)

        try:
            self.calculator_frame.set_display_value(self.display_value)
        except:
            pass

        self.sidebar_frame.lift()
        self.mode_label_display.configure(
            text=f"{self.current_mode.title()} Calculator",
            text_color=get_theme(self.theme_mode)["menu_text_color"]
        )

    # Εναλλαγή λειτουργίας (mode/frame)
    def switch_mode(self, new_mode):
        self.current_mode = new_mode
        self.show_calculator_frame()

    # Αλλαγή θέματος εμφάνισης
    def switch_theme(self, new_theme):
        self.theme_mode = new_theme
        self.show_calculator_frame()

    # Εναλλαγή ήχου on/off
    def toggle_sound(self):
        global sound_enabled_global
        sound_enabled_global = not sound_enabled_global
        self.sound_enabled = sound_enabled_global
        self.sound_button.configure(image=self.sound_on_img if self.sound_enabled else self.sound_off_img)
        self.show_calculator_frame()

    # Αντιμετώπιση πατήματος πλήκτρων από τον χρήστη
    def on_key_press(self, event):
        key = event.char  # Use the actual character pressed
        if self.calculator_frame and hasattr(self.calculator_frame, "handle_key_input"):
            self.calculator_frame.handle_key_input(key)




# Εκκίνηση της εφαρμογής
if __name__ == "__main__":
    app = MainCalculatorApp()
    app.mainloop()