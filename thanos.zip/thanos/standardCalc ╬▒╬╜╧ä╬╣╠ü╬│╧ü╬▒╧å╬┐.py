# standardCalc.py
# ----------------------------------------------------------
# Αυτό το αρχείο υλοποιεί έναν τυπικό υπολογιστή (standard calculator)
# με χρήση της βιβλιοθήκης customtkinter. Ο υπολογιστής υποστηρίζει
# αριθμητικές πράξεις, θεματική εμφάνιση, υποστήριξη ήχου και πρόσβαση
# σε online manual.

# Εισαγωγές απαραίτητων βιβλιοθηκών
import customtkinter  # Η customtkinter είναι επέκταση του tkinter με πιο σύγχρονο UI (Widgets με themes, dark mode κλπ)
import webbrowser      # Για να ανοίξουμε σύνδεσμο στο browser (το manual μας)

from themeManager import get_theme  # Εισάγουμε τη συνάρτηση που επιστρέφει ένα dictionary με τα χρώματα του theme
from buttonHandler import on_button_click  # Η βασική συνάρτηση που εκτελεί τις πράξεις όταν πατάμε κουμπιά
from mpmath import mpf  # mpf είναι τύπος αριθμού αυξημένης ακρίβειας (π.χ. 0.1+0.2 ≠ 0.3 στην float)

import pygame

pygame.mixer.init()
# Κλάση StandardCalculator: υλοποιεί τον κορμό του αριθμομηχανής
# ---------------------------------------------------------------
# Κάθε Calculator είναι Frame, δηλαδή GUI container. Τα attributes του αντικειμένου
# αφορούν το θέμα (θέμα = λεξικό με χρώματα), το display, τον ήχο, τη λογική κουμπιών.

class StandardCalculator(customtkinter.CTkFrame):
    def __init__(self, parent, theme=None, sound_enabled=True):
        super().__init__(parent)  # Αρχικοποιούμε το Frame

        # Ορισμός των βασικών attributes του αντικειμένου:
        self.theme = theme or get_theme("dark")  # Αν περαστεί θέμα, το χρησιμοποιούμε, αλλιώς παίρνουμε το "dark"
        # Το theme εδώ είναι ένα dictionary (λεξικό) με ονόματα και χρώματα (π.χ. "background": "#222222")
        # Το get_theme("dark") επιστρέφει ένα τέτοιο λεξικό ανάλογα με την επιλογή χρήστη

        self.display_var = customtkinter.StringVar(value="0")  # Το κείμενο που εμφανίζεται στο display
        self.just_evaluated = False  # Flag για να ξέρουμε αν μόλις πατήθηκε "=" ώστε να μη συνεχίσουμε αμέσως με ψηφία
        self.sound_enabled = sound_enabled  # Αν είναι ενεργός ο ήχος (true ή false)

        # Ομάδες κουμπιών για εύκολη πρόσβαση κατά το theme update
        self.operation_buttons = []
        self.symbol_buttons = []
        self.numeric_buttons = []
        self.ac_buttons = []

        self.build_ui()  # Καλούμε τη μέθοδο για να φτιαχτεί το UI



    def build_ui(self):
        # Δημιουργία του top frame που περιέχει τα πεδία εμφάνισης (display)
        self.top_buttons_frame = customtkinter.CTkFrame(self, corner_radius=0)
        self.top_buttons_frame.pack(fill="x")


        self.display_container = customtkinter.CTkFrame(self.top_buttons_frame, fg_color=self.theme["display_bg"])
        self.display_container.pack(fill="x", padx=0, pady=(0, 0))

        # Top display – περιέχει το κουμπί που ανοίγει το manual (το ✍️)
        self.top_display = customtkinter.CTkFrame(self.display_container, height=30, fg_color=self.theme["display_bg"], corner_radius=0)    
        self.top_display.pack(fill="x")

        self.manual_button = customtkinter.CTkButton(
            self.top_display,   # Το κουμπί που ανοίγει το manual
            text="✍️",
            width=30,
            height=30,
            font=("Arial", 18),
            fg_color=self.theme["manual_button_bg"],    # Το χρώμα του κουμπιού
            text_color=self.theme["manual_button_text"],    # Το χρώμα του κειμένου του κουμπιού
            hover_color=self.theme["hover_manual_button"],
            command=self.open_manual  # Όταν πατηθεί, ανοίγει σύνδεσμος σε browser
        )
        self.manual_button.pack(side="left", padx=15)   # Κουμπί manual

        self.history_button = customtkinter.CTkButton(
            self.top_display,
            text="🕘",
            width=30,
            height=30,
            font=("Arial", 18),
            fg_color=self.theme["manual_button_bg"],
            text_color=self.theme["manual_button_text"],
            hover_color=self.theme["hover_manual_button"],
            command=self.open_history_window
        )
        self.history_button.pack(side="right", padx=15)

        #Label για το ιστορικό των πράξεων
        self.history_display_var = customtkinter.StringVar(value="")    # Αρχικοποίηση του StringVar για το ιστορικό
        self.history_display = customtkinter.CTkLabel(                  # Το label που θα δείχνει το ιστορικό
            self.display_container,textvariable=self.history_display_var,   # Το textvariable είναι το StringVar που περιέχει το ιστορικό
            height=20,
            font=("Arial", 12),
            anchor="e", # Ευθυγράμμιση στα δεξιά
            fg_color=self.theme["display_bg"],  # Το χρώμα του label
            text_color=self.theme["display_text"]   # Το χρώμα του κειμένου του label
        )
        self.history_display.pack(fill="x", padx=20) # Το label γεμίζει το πλάτος του container

        # Μεσαίο label (προετοιμασία για ιστορικό ή πληροφορίες)
        self.middle_display = customtkinter.CTkLabel(
            self.display_container,
            text="",
            height=24,
            font=("Arial", 14),
            anchor="e",
            wraplength=300,
            fg_color=self.theme["display_bg"],
            text_color=self.theme["display_text"]
        )
        self.middle_display.pack(fill="x", padx=15)

        # Κύριο πεδίο για εμφάνιση αριθμών / αποτελεσμάτων
        self.display_entry = customtkinter.CTkEntry(
            self.display_container,
            textvariable=self.display_var,
            font=("Arial", 24),
            justify="right",
            state="readonly",
            height=60,
            corner_radius=0,
            border_width=0,
            fg_color=self.theme["display_bg"],
            text_color=self.theme["display_text"]
        )
        self.display_entry.pack(fill="x", padx=15, pady=(0, 0))

        self.history_log = []
        self.history_window = None  # Για το drop-down
        self.memory = mpf("0")
        self.is_degree = True
        self.is_second_function = False

        # Ορισμός κουμπιών σε πίνακα – layout 7 γραμμών με 4 κουμπιά η κάθε μία
        button_rows = [
            ["mc", "m+", "m-", "mr"],
            ["1/x", "%", "C", "AC"],
            ["x²", "√", "+/-", "÷"],
            ["7", "8", "9", "x"],
            ["4", "5", "6", "-"],
            ["1", "2", "3", "+"],
            ["0", ".", "="]
        ]

        self.bottom_buttons_frame = customtkinter.CTkFrame(self, fg_color=self.theme["bottom_frame_bg"])
        self.bottom_buttons_frame.pack(expand=True, fill="both", padx=10, pady=10)

        # Δημιουργία κουμπιών δυναμικά με βάση τα labels
        for r, row in enumerate(button_rows):
            for c, label in enumerate(row):
                if label == "":
                    continue

                # Ελέγχουμε τον τύπο του κουμπιού
                col_span = 2 if label == "=" else 1
                is_memory = label in ["mc", "m+", "m-", "mr"]
                is_operator = label in ["+", "-", "x", "÷"]
                is_symbol = label in ["1/x", "%", "+/-", "x²", "√"]
                is_ac = label in ["AC", "C", "="]
                is_numeric = label.isdigit() or label == "."

                btn = customtkinter.CTkButton(
                    master=self.bottom_buttons_frame,
                    text=label,
                    font=("Arial", 30 if is_numeric or is_operator else 20),
                    height=60,
                    hover_color=self.theme.get("hover_default"),
                    command=lambda val=label: on_button_click(self, val)
                )

                # Εφαρμογή διαφορετικών χρωμάτων ανά τύπο κουμπιού
                if is_ac:
                    btn.configure(
                        fg_color=self.theme["ac_button_bg"],
                        text_color=self.theme["ac_button_text"],
                        hover_color=self.theme["ac_hover"]
                    )
                    self.ac_buttons.append(btn)
                elif is_operator:
                    btn.configure(
                        fg_color=self.theme["op_button_bg"],
                        text_color=self.theme["op_button_text"],
                        hover_color=self.theme["op_hover"]
                    )
                    self.operation_buttons.append(btn)
                elif is_symbol:
                    btn.configure(
                        fg_color=self.theme["op_button_bg"],
                        text_color=self.theme["op_button_text"],
                        hover_color=self.theme["op_hover"]
                    )
                    self.symbol_buttons.append(btn)
                elif is_memory:
                    btn.configure(
                        fg_color=self.theme["top_button_bg"],
                        text_color=self.theme["top_button_text"],
                        hover_color=self.theme["top_button_hover"]
                    )
                else:
                    btn.configure(
                        fg_color=self.theme["num_button_bg"],
                        text_color=self.theme["num_button_text"],
                        hover_color=self.theme["num_hover"]
                    )
                    self.numeric_buttons.append(btn)

                btn.grid(row=r, column=c, columnspan=col_span, padx=4, pady=4, sticky="nsew")

                if col_span == 2:
                    self.bottom_buttons_frame.columnconfigure(c + 1, weight=0)

        for i in range(7):
            self.bottom_buttons_frame.rowconfigure(i, weight=1)
        for j in range(4):
            self.bottom_buttons_frame.columnconfigure(j, weight=1)

        self.apply_theme(self.theme)

    def get_display_value(self):
        return self.display_var.get()

    def set_display_value(self, value):
        self.display_var.set(value)

    def apply_theme(self, theme_dict):
        # Εφαρμογή χρωμάτων σε όλα τα στοιχεία σύμφωνα με το θέμα
        self.configure(fg_color=theme_dict["background"])
        self.top_buttons_frame.configure(fg_color=theme_dict["top_frame_bg"])
        self.bottom_buttons_frame.configure(fg_color=theme_dict["bottom_frame_bg"])
        self.display_container.configure(fg_color=theme_dict["display_bg"])
        self.top_display.configure(fg_color=theme_dict["display_bg"])

        self.display_entry.configure(
            fg_color=theme_dict["display_bg"],
            text_color=theme_dict["display_text"]
        )
        self.middle_display.configure(
            fg_color=theme_dict["display_bg"],
            text_color=theme_dict["display_text"]
        )
        self.manual_button.configure(
            fg_color=theme_dict["manual_button_bg"],
            text_color=theme_dict["manual_button_text"],
            hover_color=theme_dict["hover_manual_button"]
        )
        self.history_display.configure(
            fg_color=theme_dict["display_bg"],
            text_color=theme_dict["display_text"]
        )

        for btn in self.symbol_buttons + self.operation_buttons:
            btn.configure(
                fg_color=theme_dict["op_button_bg"],
                text_color=theme_dict["op_button_text"],
                hover_color=theme_dict["op_hover"]
            )

        for btn in self.numeric_buttons:
            btn.configure(
                fg_color=theme_dict["num_button_bg"],
                text_color=theme_dict["num_button_text"],
                hover_color=theme_dict["num_hover"]
            )

        for btn in self.ac_buttons:
            btn.configure(
                fg_color=theme_dict["ac_button_bg"],
                text_color=theme_dict["ac_button_text"],
                hover_color=theme_dict["ac_hover"]
            )

    def open_manual(self):
        # Ανοίγει το Google Doc manual σε browser
        webbrowser.open("https://docs.google.com/document/d/1xHKVvzsmCFrH7DBCih10n8-JnZcKpbIFKqexXh1MI8w/edit?usp=sharing")

    def open_history_window(self):
        if not self.history_log:
            return

        if self.history_window and self.history_window.winfo_exists():
            self.history_window.lift()
            return

        self.history_window = customtkinter.CTkToplevel(self)
        self.history_window.title("History")
        self.history_window.geometry("300x300")
        self.history_window.configure(fg_color=self.theme["background"])
        self.history_window.attributes("-topmost", True)

        parent_x = self.winfo_rootx()
        parent_y = self.winfo_rooty()
        popup_width = 300
        popup_height = 300
        parent_width = self.winfo_width()

        popup_x = parent_x + (parent_width - popup_width) // 2
        popup_y = parent_y + 100

        self.history_window.geometry(f"{popup_width}x{popup_height}+{popup_x}+{popup_y}")

        scroll_frame = customtkinter.CTkScrollableFrame(self.history_window)
        scroll_frame.pack(expand=True, fill="both", padx=10, pady=10)

        for entry in reversed(self.history_log[-50:]):
            btn = customtkinter.CTkButton(
                scroll_frame,
                text=entry,
                anchor="w",
                height=30,
                font=("Arial", 12),
                fg_color=self.theme["top_button_bg"],
                hover_color=self.theme["top_button_hover"],
                text_color=self.theme["top_button_text"],
                command=lambda e=entry: self.insert_history_expression(e)
            )
            btn.pack(fill="x", pady=2)


    def insert_history_expression(self, entry):
        if "=" in entry:
            expr = entry.split("=")[0].strip()
            self.display_var.set(expr)

    def handle_key_input(self, key):
        from keyboardInputHandler import handle_keyboard_input
        handle_keyboard_input(key, self)

        if key == '1/x':
            self.calculate_reciprocal()
        elif key == 'x²':
            self.calculate_square()

    def calculate_reciprocal(self):
        try:
            current_value = float(self.get_display_value())
            if current_value != 0:
                result = 1 / current_value
                self.set_display_value(str(result))
            else:
                self.set_display_value("Error")  # Handle division by zero
        except ValueError:
            self.set_display_value("Error")  # Handle invalid input

    def calculate_square(self):
        try:
            current_value = float(self.get_display_value())
            result = current_value ** 2
            self.set_display_value(str(result))
        except ValueError:
            self.set_display_value("Error")  # Handle invalid input


# Δημιουργία instance με επιλογή theme mode (π.χ. από dark σε light)
def create_standard_calculator_frame(parent, theme_mode="dark", sound_enabled=True):
    theme = get_theme(theme_mode)
    return StandardCalculator(parent, theme=theme, sound_enabled=sound_enabled)

# Δοκιμή εκτός εφαρμογής (standalone εκτέλεση)
if __name__ == "__main__":
    app = customtkinter.CTk()
    app.geometry("400x600")
    app.title("Standard Calculator Test - Clean")

    frame = StandardCalculator(app)
    frame.pack(fill="both", expand=True)

    app.mainloop()
