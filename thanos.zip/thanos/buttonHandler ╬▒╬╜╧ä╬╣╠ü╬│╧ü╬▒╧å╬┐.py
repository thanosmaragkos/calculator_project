import os
import pygame
pygame.mixer.init()

sound_path = "sounds/space_sound4.mp3"
if os.path.exists(sound_path):
    click_sound = pygame.mixer.Sound(sound_path)
else:
    click_sound = None
    print(f"Warning: Sound file '{sound_path}' not found.")

def play_click_sound(calculator):
    if hasattr(calculator, "sound_enabled") and calculator.sound_enabled and click_sound:
        click_sound.play()

import re
from mpmath import mpf, sin, cos, tan, asin, acos, atan, asinh, acosh, atanh, sqrt, log, factorial, pi, e, sinh, cosh, tanh

def on_button_click(calculator, value):
    play_click_sound(calculator)

    if value == "2nd":
        toggle_second_function(calculator)
        return
    if value in ["Rad", "Deg"]:
        toggle_angle_mode(calculator)
        return
    if value == "C":
        backspace(calculator)
        calculator.middle_display.configure(text="")  # καθαρισμός μηνύματος
        return

    if value == "AC":
        calculator.display_var.set("0")
        calculator.middle_display.configure(text="")  # καθαρισμός μηνύματος
        calculator.memory = mpf("0")
        calculator.just_evaluated = False
        #calculator.history_log.clear()
        return

    if value == "=":
        expr = calculator.display_var.get()
        try:
            result = evaluate_expression(calculator, prepare_expression(calculator, expr))

            # Αν το αποτέλεσμα είναι ακέραιο χωρίς δεκαδικά
            if result == mpf(int(result)):
                result = int(result)

            # Δημιουργία εγγραφής ιστορικού
            entry = f"{expr.replace('*', '×').replace('/', '÷')} = {result}"
            calculator.history_display_var.set(entry)
            calculator.display_var.set(str(result))
            calculator.history_log.append(entry)

            calculator.middle_display.configure(text="")  # Καθάρισε προηγούμενο μήνυμα
            calculator.just_evaluated = True

        except ZeroDivisionError:
            msg = "Cannot divide by zero"
            calculator.middle_display.configure(text=msg)
            calculator.display_var.set("Error")

        except Exception as e:
            if hasattr(e, 'args') and e.args and isinstance(e.args[0], str):
                msg = e.args[0]
            else:
                msg = "Error"

            calculator.middle_display.configure(text=msg)
            calculator.display_var.set("Error")

        return

    if value == "+/-":
        current = calculator.display_var.get()
        if current.startswith("-"):
            calculator.display_var.set(current[1:])
        else:
            calculator.display_var.set("-" + current)
        return
    if value == "mc":
        calculator.memory = mpf("0")
        return
    if value == "m+":
        try:
            calculator.memory += evaluate_expression(calculator, prepare_expression(calculator, calculator.display_var.get()))
        except:
            pass
        return
    if value == "m-":
        try:
            calculator.memory -= evaluate_expression(calculator, prepare_expression(calculator, calculator.display_var.get()))
        except:
            pass
        return
    if value == "mr":
        calculator.display_var.set(str(calculator.memory))
        return
    if value == "Rand":
        import random
        rand_num = mpf(str(random.random()))
        calculator.display_var.set(str(rand_num))
        return
    if value == "EE":
        current = calculator.display_var.get()
        if current in ["0", "Error"]:
            calculator.display_var.set("e")
        else:
            calculator.display_var.set(current + "e")
        calculator.just_evaluated = False
        return
    if value == "%":
        expr = calculator.display_var.get()
        pattern = r'(-?\d+(?:\.\d+)?)([+\-x÷])(-?\d+(?:\.\d+)?)$'
        m_obj = re.search(pattern, expr)
        if m_obj:
            try:
                A = mpf(m_obj.group(1))
                op = m_obj.group(2)
                B = mpf(m_obj.group(3))
                newB = A * (B / mpf("100")) if op in ['+', '-'] else B / mpf("100")
                new_expr = m_obj.group(1) + op + str(newB)
                calculator.display_var.set(new_expr)
            except Exception:
                calculator.display_var.set("Error")
        else:
            try:
                num = evaluate_expression(calculator, prepare_expression(calculator, expr))
                result = num / mpf("100")
                calculator.display_var.set(str(result))
            except Exception:
                calculator.display_var.set("Error")
        return

    if value in ["x²", "x³", "1/x", "√", "2ʸ", "sin", "cos", "tan", "sinh", "cosh", "tanh", "log₁₀", "log₂", "log_b", "x!"]:
        if calculator.is_second_function and value in calculator.second_map:
            value = calculator.second_map[value]
        current = calculator.display_var.get()
        transformations = {
            "sin": lambda operand: f"sin({operand})",
            "sin⁻¹": lambda operand: f"asin({operand})",
            "cos": lambda operand: f"cos({operand})",
            "cos⁻¹": lambda operand: f"acos({operand})",
            "tan": lambda operand: f"tan({operand})",
            "tan⁻¹": lambda operand: f"atan({operand})",
            "sinh": lambda operand: f"sinh({operand})",
            "sinh⁻¹": lambda operand: f"asinh({operand})",
            "cosh": lambda operand: f"cosh({operand})",
            "cosh⁻¹": lambda operand: f"acosh({operand})",
            "tanh": lambda operand: f"tanh({operand})",
            "tanh⁻¹": lambda operand: f"atanh({operand})",
            "log₁₀": lambda operand: f"log({operand})",
            "log₂": lambda operand: f"log2({operand})",
            "log_b": lambda operand: operand,  # raw, parsed in prepare_expression
            "x²": lambda operand: f"(({operand})**2)",
            "x³": lambda operand: f"(({operand})**3)",
            "1/x": lambda operand: f"(1/({operand}))",
            "√": lambda operand: f"sqrt({operand})",
            "2ʸ": lambda operand: f"((2)**({operand}))",
            "x!": lambda operand: f"factorial({operand})"
        }
        transform = transformations.get(value)
        m = re.search(r'(.*?)(-?(?:\d*\.\d+|\d+))$', current)
        if m and transform:
            prefix = m.group(1)
            operand = m.group(2)
            new_expr = f"{prefix}{transform(operand)}"
        else:
            new_expr = f"{value}(" if current in ["0", "Error"] else f"{current}{value}("
        calculator.display_var.set(new_expr)
        calculator.just_evaluated = False
        return

    if value == "yˣ":
        current = calculator.display_var.get()
        calculator.display_var.set("**" if current in ["0", "Error"] else current + "**")
        return

    if value == "ⁿ√x":
        current = calculator.display_var.get()
        calculator.display_var.set("r" if current in ["0", "Error"] else current + "r")
        return

    if calculator.just_evaluated and value in "0123456789.":
        calculator.display_var.set("0." if value == "." else value)
        calculator.just_evaluated = False
    else:
        current = calculator.display_var.get()
        if current in ["0", "Error"]:
            calculator.display_var.set("0." if value == "." else value)
        else:
            calculator.display_var.set(current + value)
        calculator.just_evaluated = False
        calculator.middle_display.configure(text="")  # σβήσε αν υπάρχει παλιό error

def toggle_angle_mode(calculator):
    calculator.is_degree = not calculator.is_degree
    new_mode = "Deg" if calculator.is_degree else "Rad"
    calculator.top_button_objects[0][1].configure(
        text=new_mode,
        fg_color=calculator.theme["common_button_fg"],
        hover_color=calculator.theme["common_button_hover"]
    )
    calculator.angle_mode_label.configure(text=new_mode)

def toggle_second_function(calculator):
    calculator.is_second_function = not calculator.is_second_function
    for row in calculator.top_button_objects:
        for btn in row:
            text = btn.cget("text")
            if calculator.is_second_function:
                if text in calculator.second_map:
                    btn.configure(text=calculator.second_map[text])
            else:
                if text in calculator.first_map:
                    btn.configure(text=calculator.first_map[text])

def backspace(calculator):
    expr = calculator.display_var.get()
    new_expr = re.sub(r'[\d.]+$', '', expr)
    if new_expr == "":
        new_expr = "0"
    calculator.display_var.set(new_expr)

def prepare_expression(calculator, expr):
    expr = re.sub(r'\b(sin|cos|tan)(\d+(\.\d+)?)\b', r'\1(\2)', expr)
    expr = expr.replace("x", "*")
    expr = expr.replace("÷", "/")
    expr = expr.replace("π", "pi")
    expr = expr.replace("√", "sqrt")
    expr = expr.replace("log₂", "log2")
    expr = expr.replace("log₁₀", "log")
    expr = re.sub(r'(\d+(\.\d+)?)r(\d+(\.\d+)?)', r'nth_root(\3,\1)', expr)
    expr = re.sub(
        r"mpf\('(\d+(\.\d+)?)'\)\s*log_b\s*mpf\('(\d+(\.\d+)?)'\)",
        r"(log(mpf('\3'))/log(mpf('\1')))",
        expr
    )
    expr = re.sub(r'(?<!\d)\.(\d+)', r'0.\1', expr)
    expr = re.sub(
        r'(?<![\w)])(-?\d+(?:\.\d+)?(?:e-?\d+)?)(?![\w(])',
        r"mpf('\1')",
        expr
    )

    #expr = re.sub(r'(?<![A-Za-z_])(-?\d+(\.\d+)?(e-?\d+)?)(?![A-Za-z_])', r"mpf('\1')", expr)
    return expr

def evaluate_expression(calculator, expr):
    def check_domain_issues(expr):
        try:
            def get_val(val):
                return float(val)

            # Trig domain checks
            if "asin" in expr or "acos" in expr:
                matches = re.findall(r'(asin|acos)\(mpf\(\'([^\']+)\'\)\)', expr)
                for func, val in matches:
                    x = get_val(val)
                    if not -1 <= x <= 1:
                        return f"Invalid input: {func} domain is [-1, 1]"
            if "acosh" in expr:
                matches = re.findall(r'acosh\(mpf\(\'([^\']+)\'\)\)', expr)
                for val in matches:
                    x = get_val(val)
                    if x < 1:
                        return "Invalid input: acosh domain is [1, ∞)"
            if "atanh" in expr:
                matches = re.findall(r'atanh\(mpf\(\'([^\']+)\'\)\)', expr)
                for val in matches:
                    x = get_val(val)
                    if not -1 < x < 1:
                        return "Invalid input: atanh domain is (-1, 1)"

            # log(x), log2(x)
            if "log" in expr:
                matches = re.findall(r'log\(mpf\(\'([^\']+)\'\)\)', expr)
                for val in matches:
                    x = get_val(val)
                    if x <= 0:
                        return "Invalid input: log(x) domain is (0, ∞)"
            if "log2" in expr:
                matches = re.findall(r'log2\(mpf\(\'([^\']+)\'\)\)', expr)
                for val in matches:
                    x = get_val(val)
                    if x <= 0:
                        return "Invalid input: log2(x) domain is (0, ∞)"

            # sqrt(x)
            if "sqrt" in expr:
                matches = re.findall(r'sqrt\(mpf\(\'([^\']+)\'\)\)', expr)
                for val in matches:
                    x = get_val(val)
                    if x < 0:
                        return "Invalid input: sqrt(x) domain is [0, ∞)"

            # 1/x
            if "1/(" in expr:
                matches = re.findall(r'1/\(mpf\(\'([^\']+)\'\)\)', expr)
                for val in matches:
                    x = get_val(val)
                    if x == 0:
                        return "Cannot divide by zero"

        except:
            pass
        return None

    domain_msg = check_domain_issues(expr)
    if domain_msg:
        raise ValueError(domain_msg)

    funcs = {
        'mpf': mpf,
        'sqrt': sqrt,
        'nth_root': lambda x, n: n ** (mpf("1") / x),
        'sinh': sinh,
        'cosh': cosh,
        'tanh': tanh,
        'asinh': asinh,
        'acosh': acosh,
        'atanh': atanh,
        'log': lambda x: log(x) / log(10),
        'log2': lambda x: log(x) / log(2),
        'factorial': factorial,
        'pi': pi,
        'e': e,
        'EE': lambda x, y: x * (10 ** y)
    }

    if calculator.is_degree:
        funcs.update({
            'sin': lambda x: sin(x * pi / 180),
            'cos': lambda x: cos(x * pi / 180),
            'tan': lambda x: tan(x * pi / 180),
            'asin': lambda x: (asin(x) * 180 / pi),
            'acos': lambda x: (acos(x) * 180 / pi),
            'atan': lambda x: (atan(x) * 180 / pi),
        })
    else:
        funcs.update({
            'sin': sin,
            'cos': cos,
            'tan': tan,
            'asin': asin,
            'acos': acos,
            'atan': atan,
        })

    return eval(expr, {"__builtins__": None}, funcs)
