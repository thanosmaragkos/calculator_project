#frameManager.py
from standardCalc import StandardCalculator
from scientificCalc import ScientificCalculator
from currencyConverter import CurrencyConverter
from numberConverter import NumberBaseConverter



frame_data = {
    "standard": {
        "frame": StandardCalculator,
        "icon_path": "images/standard.png",
    },
    "scientific": {
        "frame": ScientificCalculator,
        "icon_path": "images/scientific.png",
    },

    "Currency Converter": {
        "frame": CurrencyConverter,
        "icon_path": "images/converter.png"
    },

    "Number Converter": {
        "frame": NumberBaseConverter,
        "icon_path": "images/converter.png"
    },

}
