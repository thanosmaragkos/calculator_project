from fractions import Fraction
import customtkinter as ctk
import tkinter as tk

from themeManager import DARK_THEME


class NumberBaseConverter(ctk.CTkFrame):
    def __init__(self, master, theme, **kwargs):
        super().__init__(master, fg_color=theme.get("background", "#222222"), corner_radius=0)
        self.theme = theme
        self.grid_columnconfigure((0, 4), weight=0, minsize=60)
        self.grid_columnconfigure((1, 2, 3), weight=1)
        self.grid_rowconfigure(list(range(10)), weight=1)

        self.title_label = ctk.CTkLabel(
            self, text="NUMBER BASE CONVERTER",
            font=("Arial", 18, "bold"),
            text_color=theme.get("display_text", "#00ff00")
        )
        self.title_label.grid(row=0, column=0, columnspan=5, padx=20, pady=(20, 40))

        self.from_label = ctk.CTkLabel(self, text="FROM BASE", font=("Arial", 14),
                                       text_color=theme.get("label_text", "#ffffff"))
        self.from_label.grid(row=1, column=0,  columnspan=2, padx=(20, 5), sticky="e")

        self.to_label = ctk.CTkLabel(self, text="TO BASE", font=("Arial", 14),
                                     text_color=theme.get("label_text", "#ffffff"))
        self.to_label.grid(row=1, column=3, columnspan=2, padx=(5, 20), sticky="w")

        bases = ["2", "8", "10", "16"]

        self.from_base_menu = ctk.CTkComboBox(
            self, values=bases, border_width=2,
            command=lambda _: self.update_allowed_digits_label(),
            button_color=theme.get("menu_button_bg", "#eb7c16"),
            dropdown_fg_color=theme.get("dropdown_fg", "#4f4f4f"),
            dropdown_text_color=theme.get("menu_text_color", "#ffffff"),
            text_color=theme.get("menu_text_color", "#ffffff"),
            border_color=theme.get("menu_button_bg", "#eb7c16"))
        self.from_base_menu.set("10")
        self.from_base_menu.grid(row=2, column=0, columnspan=2, padx=(30, 5), pady=(0, 2), sticky="ew")

        self.swap_button = ctk.CTkButton(self, text="↔", font=("Arial", 16), width=40,
                                         command=self.swap_bases,
                                         fg_color=theme.get("special_button_fg", "#eb7c16"))
        self.swap_button.grid(row=2, column=2, padx=(15, 15), pady=(0, 2), sticky="ew")

        self.to_base_menu = ctk.CTkComboBox(
            self, values=bases, border_width=2,
            button_color=theme.get("menu_button_bg", "#eb7c16"),
            dropdown_fg_color=theme.get("dropdown_fg", "#4f4f4f"),
            dropdown_text_color=theme.get("menu_text_color", "#ffffff"),
            text_color=theme.get("menu_text_color", "#ffffff"),
            border_color=theme.get("menu_button_bg", "#eb7c16"))
        self.to_base_menu.set("2")
        self.to_base_menu.grid(row=2, column=3, columnspan=2, padx=(5, 30), pady=(0, 2), sticky="ew")

        self.allowed_digits_label = ctk.CTkLabel(self, text="", font=("Arial", 11, "italic"),
                                                 text_color=self.theme.get("placeholder_text", "#aaaaaa"))
        self.allowed_digits_label.grid(row=3, column=1, columnspan=3, pady=(0, 10))
        self.update_allowed_digits_label()

        self.input_label = ctk.CTkLabel(
            self, text="NUMBER", font=("Arial", 16, "bold"),
            text_color=theme.get("label_text", "#ffffff")
        )
        self.input_label.grid(row=4, column=1, columnspan=3, pady=(10, 2), sticky="s")

        self.input_entry = ctk.CTkEntry(
            self,
            fg_color=theme.get("entry_fg", "#ffffff"),
            text_color=theme.get("text_input", "#000000"),
            font=("Arial", 20, "bold"),
            height=40,
            justify="center",
            placeholder_text="e.g. 12.75",
            placeholder_text_color=self.theme.get("placeholder_text", "#BEBEBE")
        )
        self.input_entry.grid(row=5, column=1, columnspan=3, padx=10, pady=(0, 0), sticky="ew")
        self.input_entry.bind("<Return>", lambda event: self.convert_number())

        self.tooltip_label = ctk.CTkLabel(
            self, text="", font=("Arial", 12),
            text_color=self.theme.get("error_text", "#ff4444")
        )
        self.tooltip_label.grid(row=6, column=0, columnspan=4, pady=(0, 2))

        self.convert_button = ctk.CTkButton(
            self, text="CONVERT", font=("Arial", 16, "bold"), height=50,
            command=self.convert_number,
            fg_color=theme.get("special_button_fg", "#eb7c16"),
            text_color=theme.get("op_button_text", "#ffffff"),
            hover_color=theme.get("op_hover", "#5e5e5e"))
        self.convert_button.grid(row=7, column=1, columnspan=3, padx=10, pady=(0, 20), sticky="ew")

        self.result_label = ctk.CTkLabel(self, text="RESULT", font=("Arial", 14, "bold"),
                                         text_color=theme.get("label_text", "#ffffff"))
        self.result_label.grid(row=8, column=1, columnspan=3, pady=(20, 2), sticky="s")

        self.result_entry = ctk.CTkEntry(
            self, font=("Arial", 18, "bold"), height=40,
            text_color=theme.get("display_text", "#00ff00"),
            fg_color=theme.get("display_bg", "#000000"), justify="center"
        )
        self.result_entry.grid(row=9, column=1, columnspan=3, padx=10, pady=(2, 0), sticky="ewn")


        self.copy_button = ctk.CTkButton(
            self,
            text="📋",
            width=1,
            height=40,
            font=("Arial", 16),
            fg_color=self.theme.get("special_button_fg", "#eb7c16"),
            border_width=2,
            border_color=theme.get("border_color", "#000000"),
            hover_color="#000000",
            text_color=self.theme.get("special_button_text", "#ffffff"),
            command=self.copy_result
        )
        self.copy_button.grid(row=9, column=4, pady=(2, 0), sticky="wn")

        self.copy_tooltip_label = ctk.CTkLabel(
            self,
            text="",
            font=("Arial", 11, "italic"),
            text_color="#33ff33"
        )
        self.copy_tooltip_label.grid(row=10, column=2, columnspan=2, pady=(0, 60), padx=15, sticky="en")

    #-----------------------------------------------------------------------------------------------------------------------




    def update_allowed_digits_label(self):
        base = int(self.from_base_menu.get())
        digits = "0123456789ABCDEF"[:base]
        self.allowed_digits_label.configure(text=f"Allowed characters: {digits}")

    def swap_bases(self):
        from_base = self.from_base_menu.get()
        to_base = self.to_base_menu.get()
        self.from_base_menu.set(to_base)
        self.to_base_menu.set(from_base)
        self.update_allowed_digits_label()

    def convert_number(self):
        value = self.input_entry.get().strip().replace(",", ".")
        from_base = int(self.from_base_menu.get())
        to_base = int(self.to_base_menu.get())

        try:
            DIGIT_MAP = {
                '0': 0, '1': 1, '2': 2, '3': 3, '4': 4,
                '5': 5, '6': 6, '7': 7, '8': 8, '9': 9,
                'A': 10, 'B': 11, 'C': 12, 'D': 13, 'E': 14, 'F': 15,
                'a': 10, 'b': 11, 'c': 12, 'd': 13, 'e': 14, 'f': 15
            }

            REVERSE_MAP = "0123456789ABCDEF"

            if "." in value:
                int_part, frac_part = value.split(".")
            else:
                int_part, frac_part = value, ""

            allowed_digits = REVERSE_MAP[:from_base]
            full_value = int_part + frac_part
            if not all(char in allowed_digits or char.lower() in DIGIT_MAP for char in full_value):
                raise ValueError

            decimal_int = 0
            for i, digit in enumerate(reversed(int_part.upper())):
                decimal_int += DIGIT_MAP[digit] * (from_base ** i)

            decimal_frac = Fraction(0, 1)
            for i, digit in enumerate(frac_part.upper(), start=1):
                decimal_frac += Fraction(DIGIT_MAP[digit], from_base ** i)

            total = Fraction(decimal_int) + decimal_frac

            if to_base == 10:
                result = float(total)
                result = f"{result:.15f}".rstrip('0').rstrip('.')
            else:
                int_val = total.numerator // total.denominator
                digits = []
                while int_val > 0:
                    digits.append(REVERSE_MAP[int_val % to_base])
                    int_val //= to_base
                int_conv = ''.join(reversed(digits)) if digits else "0"

                frac = total - int(total)
                frac = Fraction(frac)

                digits = []
                seen = {}
                periodic_index = None

                numerator = frac.numerator
                denominator = frac.denominator

                for i in range(100):
                    if numerator == 0:
                        break
                    key = (numerator, denominator)
                    if key in seen:
                        periodic_index = seen[key]
                        break
                    seen[key] = i

                    numerator *= to_base
                    digit = numerator // denominator
                    digits.append(REVERSE_MAP[digit])
                    numerator %= denominator

                if periodic_index is not None:
                    non_periodic = ''.join(digits[:periodic_index])
                    periodic = ''.join(digits[periodic_index:])
                    frac_conv = f"{non_periodic}({periodic})"
                else:
                    frac_conv = ''.join(digits).rstrip('0')

                result = f"{int_conv}.{frac_conv}" if frac_conv else int_conv

            self.result_entry.delete(0, tk.END)
            self.result_entry.insert(0, str(result))
            self.tooltip_label.configure(text="")

        except:
            last = REVERSE_MAP[from_base - 1]
            self.tooltip_label.configure(text=f"Accepted digits: 0-{last}")
            self.result_entry.delete(0, tk.END)

    def copy_result(self):
        result = self.result_entry.get()
        self.clipboard_clear()
        self.clipboard_append(result)
        self.update()

        # Εμφάνιση του tooltip
        self.copy_tooltip_label.configure(text="✔ Copied!")
        self.after(1500, lambda: self.copy_tooltip_label.configure(text=""))


if __name__ == "__main__":
    import customtkinter as ctk

    app = ctk.CTk()
    app.geometry("400x600")
    app.title("Number Converter")

    frame = NumberBaseConverter(app, theme=DARK_THEME)
    frame.pack(expand=True, fill="both")

    app.mainloop()


