# keyboardInputHandler.py
from buttonHandler import on_button_click

def handle_keyboard_input(char, calculator):
    key_map = {
        '\r': '=',            # Enter or =
        '\n': '=',           # Alternate newline
        '\x08': 'C',      # Backspace
        '*': '*',
        '/': '÷',
        '+': '+',
        '-': '-',
        '.': '.',
        '%': '%',           # Shift + 5 (%)
        '=': '=',
        'x': '*',
        '(': '(',
        ')': ')',
        'C': 'AC',          # C key to All Clear
        'E': '+/-',          #  Toggle Sign
        'R': '1/x' ,         #  Reciprocal
        'Q': 'x²' ,          #  Square
        'S': '√',            #  Square Root
        'T': 'mc',           # Memory Clear
        'Y': 'm+',           # Memory Add
        'U': 'm-',           # Memory Subtract
        'I': 'mr',           # Memory Recall
        'H' : 'sin',         #sine trigonometric function
        'J' : 'cos',         #trigonometric function that relates an angle of a right-angled triangle
        'K' : 'tan',         #tangent' function
        'L' : 'sinh',        #Hyperbolic sine function
        'Z' : 'cosh',        #hyperbolic cosine function
        'X' : 'tanh',        #hyperbolic tangent function
        'V' : 'π',           #3,14
        'B' : 'x!',          #factorial function



    }

    mapped = key_map.get(char, char if char.isdigit() or char == '.' else None)

    if mapped:
        on_button_click(calculator, mapped)





